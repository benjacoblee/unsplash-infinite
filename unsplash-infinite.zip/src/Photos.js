import React from "react";
import { useEffect } from "react";

const Photos = ({ photos }) => {
    useEffect(() => {}, []);

    if (photos.length) {
        return photos.map((photo) => {
            const {
                id,
                description,
                alt_description,
                urls,
                created_at
            } = photo;
            return (
                <div key={id}>
                    <img src={urls.regular} alt={alt_description} />
                    <p> {description || "No caption provided"}</p>
                </div>
            );
        });
    } else {
        console.log("HIHi");
        return null;
    }
};

export default Photos;
